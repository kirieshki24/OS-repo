import requests
import json

BASE_URL = "http://localhost:8080"

def test_fibonacci():
    response = requests.get(f"{BASE_URL}/fibonacci?n=5")
    assert response.status_code == 200
    data = response.json()
    assert data["fibonacci"] == [0, 1, 1, 2, 3]

    response = requests.get(f"{BASE_URL}/fibonacci?n=-1")
    assert response.status_code == 400

def test_palindrome():
    response = requests.get(f"{BASE_URL}/palindrome?num=121")
    assert response.status_code == 200
    assert response.json()["is_palindrome"] is True

    response = requests.get(f"{BASE_URL}/palindrome?num=123")
    assert response.json()["is_palindrome"] is False

def test_reverse_list():
    payload = {"numbers": [1, 2, 3, 4, 5]}
    response = requests.post(f"{BASE_URL}/reverse-list", json=payload)
    assert response.status_code == 200
    assert response.json()["reversed"] == [5, 4, 3, 2, 1]

    # Empty list
    payload = {"numbers": []}
    response = requests.post(f"{BASE_URL}/reverse-list", json=payload)
    assert response.json()["reversed"] == []

if __name__ == "__main__":
    test_fibonacci()
    test_palindrome()
    test_reverse_list()
    print("All API tests passed!")