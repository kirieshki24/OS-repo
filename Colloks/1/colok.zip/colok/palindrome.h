#ifndef PALINDROME_H
#define PALINDROME_H

class PalindromeChecker {
public:
    static bool is_palindrome(int num);
};

#endif