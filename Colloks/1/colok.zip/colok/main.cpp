#include <cpprest/http_listener.h>
#include <cpprest/json.h>
#include <iostream>
#include "fibonacci.h"
#include "palindrome.h"
#include "linkedlist.h"

using namespace web;
using namespace web::http;
using namespace web::http::experimental::listener;

class RestService {
public:
    RestService(utility::string_t url) : m_listener(url) {
        m_listener.support(methods::GET, std::bind(&RestService::handle_get, this, std::placeholders::_1));
        m_listener.support(methods::POST, std::bind(&RestService::handle_post, this, std::placeholders::_1));
    }

    void handle_get(http_request request) {
        auto path = request.relative_uri().path();
        if (path == U("/fibonacci")) {
            handle_fibonacci(request);
        }
        else if (path == U("/palindrome")) {
            handle_palindrome(request);
        }
        else {
            request.reply(status_codes::NotFound, U("Endpoint not found."));
        }
    }

    void handle_post(http_request request) {
        auto path = request.relative_uri().path();
        if (path == U("/reverse-list")) {
            handle_reverse_list(request);
        }
        else {
            request.reply(status_codes::NotFound, U("Endpoint not found."));
        }
    }

private:
    http_listener m_listener;

    void handle_fibonacci(http_request request) {
        auto params = uri::split_query(request.relative_uri().query());
        if (params.find(U("n")) == params.end()) {
            request.reply(status_codes::BadRequest, U("Missing parameter 'n'."));
            return;
        }

        int n;
        try {
            n = std::stoi(params[U("n")]);
            if (n <= 0) throw std::invalid_argument("n must be positive.");
        }
        catch (...) {
            request.reply(status_codes::BadRequest, U("Invalid parameter 'n'. Must be a positive integer."));
            return;
        }

        Fibonacci fib;
        auto sequence = fib.get_fibonacci(n);

        json::value response;
        response[U("fibonacci")] = json::value::array();
        for (int i = 0; i < n; ++i) {
            response[U("fibonacci")][i] = json::value::number(sequence[i]);
        }

        request.reply(status_codes::OK, response);
    }

    void handle_palindrome(http_request request) {
        auto params = uri::split_query(request.relative_uri().query());
        if (params.find(U("num")) == params.end()) {
            request.reply(status_codes::BadRequest, U("Missing parameter 'num'."));
            return;
        }

        int num;
        try {
            num = std::stoi(params[U("num")]);
        }
        catch (...) {
            request.reply(status_codes::BadRequest, U("Invalid parameter 'num'. Must be an integer."));
            return;
        }

        bool is_palindrome = PalindromeChecker::is_palindrome(num);

        json::value response;
        response[U("is_palindrome")] = json::value::boolean(is_palindrome);
        response[U("number")] = json::value::number(num);

        request.reply(status_codes::OK, response);
    }

    void handle_reverse_list(http_request request) {
        request.extract_json()
            .then([=](json::value body) {
            if (!body.has_array_field(U("numbers"))) {
                request.reply(status_codes::BadRequest, U("Missing 'numbers' array in JSON."));
                return;
            }

            auto numbers = body[U("numbers")].as_array();
            LinkedList list;

            for (const auto& num : numbers) {
                list.append(num.as_integer());
            }

            list.reverse();
            auto reversed = list.toVector();

            json::value response;
            response[U("reversed")] = json::value::array();
            for (size_t i = 0; i < reversed.size(); ++i) {
                response[U("reversed")][i] = json::value::number(reversed[i]);
            }

            request.reply(status_codes::OK, response);
                })
            .wait();
    }
};

int main() {
    utility::string_t address = U("http://localhost:8080");
    RestService service(address);

    try {
        service.open().wait();
        std::cout << "Server is listening at " << address << std::endl;
        std::string line;
        std::getline(std::cin, line); // Keep server running
        service.close().wait();
    }
    catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }

    return 0;
}