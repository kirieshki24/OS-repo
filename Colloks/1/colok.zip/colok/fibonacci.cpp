#include "fibonacci.h"
#include <stdexcept>

vector<unsigned long long> Fibonacci::get_fibonacci(float n) {
    if (n <= 0 || n != static_cast<int>(n))
        throw string("The number must be a positive integer.");

    int num = static_cast<int>(n);
    vector<unsigned long long> result;
    unsigned long long a = 0, b = 1;
    for (int i = 0; i < num; ++i) {
        result.push_back(a);
        unsigned long long temp = a;
        a = b;
        b += temp;
    }
    return result;
}