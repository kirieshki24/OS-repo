#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <vector>

class Node {
public:
    int data;
    Node* next;
    Node(int d);
};

class LinkedList {
private:
    Node* head;
public:
    LinkedList();
    ~LinkedList();
    void append(int data);
    void reverse();
    std::vector<int> toVector() const;
};

#endif