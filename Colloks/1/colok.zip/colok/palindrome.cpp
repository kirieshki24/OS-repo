#include "palindrome.h"
#include <string>

using namespace std;

bool PalindromeChecker::is_palindrome(int num) {
    if (num < 0) return false;
    string s = to_string(num);
    int left = 0, right = s.size() - 1;
    while (left < right) {
        if (s[left] != s[right]) return false;
        left++;
        right--;
    }
    return true;
}