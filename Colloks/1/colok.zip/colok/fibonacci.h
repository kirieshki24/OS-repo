#ifndef FIBONACCI_H
#define FIBONACCI_H

#include <vector>
#include <string>

using namespace std;

class Fibonacci {
public:
    vector<unsigned long long> get_fibonacci(float n);
};

#endif